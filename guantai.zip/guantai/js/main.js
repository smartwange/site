!(function(){
	var mySwiper = new Swiper("#banner .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
	});
	
})();
!(function(){
	$("#main .fourth .subnavs li").on('click',function() {
		$("#main .fourth .subnavs li").removeClass('active');
		$(this).addClass('active');
		$("#main .fourth .contents .boxs").removeClass('active');
		$("#main .fourth .contents .boxs").eq($(this).index()).addClass('active');
	})
})();
!(function(){
    var mySwiper3 = new Swiper("#main .seventh .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    slidesPerView : 6,
	    navigation: {
	      nextEl: '.swiper-button-prev',
	      prevEl: '.swiper-button-next',
	    },
		    
	});
})();
!(function(){
	$("#product .down .change li").on('click',function() {
		$("#product .down .change li").removeClass('active');
		$(this).addClass('active');
	})
})();
!(function(){
    var mySwiper3 = new Swiper("#about .content .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
        spaceBetween:30,
	    loop:true,
	    slidesPerView : 3,
	    navigation: {
	      nextEl: '.swiper-button-prev',
	      prevEl: '.swiper-button-next',
	    },
		    
	});
})();
!(function(){
	$("#navmore  li").on('click',function() {
		$("#navmore  li").removeClass('active');
		$(this).addClass('active');
	})
})();