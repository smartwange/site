(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();

(function(){
	$(document).on('click','#changenav',function(){
		if ($(this).siblings('ul').css('display')=='none') {
			$(this).css('background-image','url("img/menu1.png")');
		    $(this).css('height','0.32rem');
		     $(this).siblings('ul').css('display','block');
		} else{
			$(this).css('background-image','url("img/navs.png")');
		    $(this).css('height','0.26rem');
		    $(this).siblings('ul').css('display','none');
		}
	})
})();

(function(){
	var mySwiper = new Swiper('.swiper-container', {
	      loop:true,
	      nested:true,
	      autoplay:5000,
	      prevButton:'.swiper-button-prev',
	      nextButton:'.swiper-button-next'  
	});
})();