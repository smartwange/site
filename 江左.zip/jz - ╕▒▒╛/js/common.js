!(function(){
	function press(){
		var aProgress=document.querySelectorAll("#progress");
		for (var i = 0; i < aProgress.length; i++) {
			var progress=parseInt(aProgress[i].childNodes[1].data)/100;
			var progressLength=parseInt(aProgress[i].childNodes[0].offsetWidth);
			aProgress[i].childNodes[0].childNodes[0].style.width=progress*progressLength+"px";
		}
	}
	press();
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#main .second .navs li');
    var aMainfivecontents=document.querySelectorAll('#main .second .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
            press();
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#project_detail .second .navs li');
    var aMainfivecontents=document.querySelectorAll('#project_detail .second .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    //为所有的img添加id myImg
     var pre = document.getElementById('next');
     var  next= document.getElementById('pre');
     var modal = document.getElementById('myModal');
     var aImg=document.querySelectorAll("#target img");
     var modalImg = document.getElementById("img01");
     var captionText = document.getElementById("caption");
     for (var i = 0; i <aImg.length; i++) {
        aImg[i].addEventListener('click', function(){
            var that=this;
            var temp = i;
            modal.style.display = "block";
            modalImg.setAttribute('src',that.src);
            modalImg.alt = that.alt;
            captionText.innerHTML = that.alt; 
            var getIndex = function () {
                return Array.prototype.slice.call(that.parentNode.children).indexOf(that);
            } 
            var ind=getIndex();
            pre.addEventListener('click', function(){
                if(ind<(aImg.length-1)){
                    ind+=1;
                    modalImg.setAttribute('src',aImg[ind].src);
                    modalImg.alt = aImg[ind].alt;
                    captionText.innerHTML = aImg[ind].alt; 
                }
            });
            next.addEventListener('click', function(){
                if(ind>0){
                    ind-=1;
                    modalImg.setAttribute('src',aImg[ind].src);
                    modalImg.alt = aImg[ind].alt;
                    captionText.innerHTML = aImg[ind].alt; 
                }
            });
        });
     }
    // 获取 <span> 元素，设置关闭模态框按钮
    var span = document.getElementsByClassName("close")[0];

    // 点击 <span> 元素上的 (x), 关闭模态框
    span.onclick = function() { 
        modal.style.display = "none";
    }
})();
!(function(){
    var alines=document.querySelectorAll("#project_detail .second .left .up .navs li");
    var lins=document.querySelector("#project_detail .second .left .up .navs .lins");
    var oLineleng=alines[0].offsetHeight*alines.length;
    lins.style.height=(oLineleng+24)+"px";
})();