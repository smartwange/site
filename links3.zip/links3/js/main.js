(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 19.2+ 'px';
	}
})();

(function(){
	var swiperH = new Swiper('.swiper-container-h', {
		pagination:'.pagination1',
	    paginationClickable: true,
	    mousewheelControl: true,
	    direction: 'vertical',
//	    spaceBetween: 50,
	    onSlideChangeStart:function(swiper){//滑动父级需要激活滚轮事件
	        swiper.enableMousewheelControl();
	    }
	});
	 window.onload=function(){
//		var swp1=document.getElementsByClassName('swiper-container-h')[0];
//	    var sp=swp1.getElementsByClassName('swiper-pagination-bullet');
	    var sp=$('.pagination1').find('.swiper-pagination-bullet');
	    console.log(sp);
	    var date=['首页','优势','产品','新闻','方案','技术','团队'];
		for (var i=0;i<sp.length;i++) {
			sp[i].innerHTML=date[i];
		}
	}
})();


(function(){
   
})();


(function(){
	var mySwiper = new Swiper('#swiper-container3', {
      loop:true,
      slidesPerView:3,
      nested:true,
      autoplay:8000,
      prevButton:'.swiper-button-prev',
      nextButton:'.swiper-button-next'  
	});
	
	var mySwiper = new Swiper('#swiper-container5', {
      loop:true,
      nested:true,
      autoplay:8000,
      prevButton:'.swiper-button-prev',
      nextButton:'.swiper-button-next'  
	});
})();

(function(){
	var mySwiper3 = new Swiper('#swiper-container7', {
	    pagination:'.pagination7',
	    paginationClickable :true,
        loop:true,
        slidesPerView:3,
        nested:true,
        autoplay:8000,
	});
})();

(function(){
	var mySwiper3 = new Swiper('#swiper-container9', {
	    pagination:'.pagination9',
	    paginationClickable :true,
        loop:true,
        slidesPerView:3,
        nested:true,
        autoplay:8000,
	});
})();

(function(){
	$(".same #erweima").hover(
	  function () {
	    $('.same .pics').css('display','block');
	  },
	  function () {
	    $('.same .pics').css('display','none');
	  }
	);
})();