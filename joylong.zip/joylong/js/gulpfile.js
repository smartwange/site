'use strict';
var gulp = require('gulp');
//压缩html
var htmlmin = require('gulp-htmlmin');
gulp.task('html', function(){
    gulp.src(['./joylong/*.html'])
        .pipe(htmlmin({
            collapseWhitespace: true,//压缩HTML
            removeComments: true,//清除HTML注释
            removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
            removeStyleLinkTypeAttributes: true,//删除<link>的type="text/css"
            minifyJS: true,//压缩页面JS
            minifyCSS: true//压缩页面CSS
        }))
        .pipe(gulp.dest('dist'));
});

//压缩css
var cssnano = require('gulp-cssnano');
gulp.task('style', function(){
    gulp.src(['./joylong/css/*.css'])
        .pipe(cssnano())
        .pipe(gulp.dest('dist/css'));
});

//压缩js
var uglify = require('gulp-uglify');
gulp.task('script', function(){
    gulp.src(['./joylong/js/*.js'])
        .pipe(uglify({
            mangle: false// 跳过函数名，使其不被压缩，函数名也压缩可改为true
        }))
        .pipe(gulp.dest('dist/js'));
});

//同步代码变化
gulp.task('dist', function(){
    gulp.watch(['./*.html'], ['html']);
    gulp.watch(['./css/*.css'], ['style']);
    gulp.watch(['./js/*.js'], ['script']);
});

gulp.task("default", ["html","style","script","dist"]);