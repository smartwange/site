!(function(){
	var mySwiper = new Swiper("#banner .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
	});
})();
!(function(){
	$("#menu").click(function(){
		$("nav").css('display','block');
		$(this).removeClass('active');
		$("#close").addClass('active');
	})
	$("#close").click(function(){
		$("nav").css('display','none');
		$(this).removeClass('active');
		$("#menu").addClass('active');
	})
})();