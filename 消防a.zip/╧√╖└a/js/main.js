(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();

(function(){
    var mySwiper = new Swiper ('.swiper-container', {
	  spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }         
	});
})();


(function(){
	$(document).on('click','#changenav',function(){
		var navmore=$('.navmore');
		if (navmore.css('display')=='none') {
			navmore.css('display','block');
		}
	})
   
    $(document).on('click','#navclose',function(){
		var navmore=$('.navmore');
		if (navmore.css('display')=='block') {
			navmore.css('display','none');
		}
	})
    
    var mySwiper = new Swiper('.swiper-container3', {
	  loop : false,
      slidesPerView : 'auto',
      loopedSlides :5,
	});
	
	var mySwiper = new Swiper('.swiper-container5', {
	  loop : false,
      slidesPerView : 'auto',
      loopedSlides :'auto',
	});
	
	$(document).on('click','#hos',function(){
    	if ($(this).siblings('ul').css('display')=='none') {
    		$(this).siblings('ul').css('display','block');
    		$(this).children('span').addClass('cur');
    	} else{
    		$(this).siblings('ul').css('display','none');
    		$(this).children('span').removeClass('cur');
    	}
    })
	
	$(document).on('click','#toTop',function(){
   	    $('html,body').animate({ scrollTop: 0 }, 1000);
   })
})();