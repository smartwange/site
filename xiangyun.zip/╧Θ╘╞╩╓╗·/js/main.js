(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();
(function(){ 
	$(document).on('click','#toTop',function(){
//		$('body,html').scrollTop(0);
		$('body,html').animate({'scrollTop':'0'},500);
	})
})();
(function(){ 
	$(document).on('click','#sub_top #toBack',function(){
		window.history.back();
	})
})();
(function(){
	$(document).on('click','#top #nav',function(){
		$('#top .navs').css('display','block');
	})
	$(document).on('click','#top #close',function(){
		$('#top .navs').css('display','none');
	})
})();	

(function(){
	$(document).on('click','#sub_top #nav',function(){
		$('#sub_top .navs').css('display','block');
	})
	$(document).on('click','#sub_top #close',function(){
		$('#sub_top .navs').css('display','none');
	})
	
	
	
	$(document).on('click','#top #serach',function(){
        if ($('#top .forms').css('display')=='none') {
        	$('#top .forms').css('display','block');
        } else{
        	$('#top .forms').css('display','none');
        }
	})
	$(document).on('click','#sub_top #serach',function(){
        if ($('#sub_top .forms').css('display')=='none') {
        	$('#sub_top .forms').css('display','block');
        } else{
        	$('#sub_top .forms').css('display','none');
        }
	})
})();	
(function(){
    var swiper = new Swiper('.swiper-container', {
	  autoplay:3000,
	   pagination: '.swiper-pagination',
	   paginationClickable: true,
	    loop: true,
	});
		var swiper3 = new Swiper('.swiper-container3', {
	      autoplay:3800,
		  slidesPerView:2,
		});
		var swiper5 = new Swiper('.swiper-container5', {
			autoplay:4000,
		  slidesPerView:2,
		});
		var swiper2 = new Swiper('.swiper-container2', {
			autoplay:4000,
		    slidesPerView:2,
		    prevButton:'.swiper-button-prev',
		    nextButton:'.swiper-button-next',
		});
		
})();




(function(){
//$('#about_recruit .boxs_contents')
  if ($('#about_recruit .boxs_contents').hasClass('active')) {
  	 $('#about_recruit .boxs_contents.active').prev().children('img').css('transform','rotate(90deg)');
  }
  $(document).on('click','#about_recruit  .second .tittles',function(){
//	    $('#about_recruit .boxs_contents').removeClass('active');
//	    $(this).children('img').css('transform','rotate(0deg)');
        if ($(this).next().hasClass('active')) {
        	$(this).children('img').css('transform','rotate(0deg)');
        	$(this).next().removeClass('active');
        } else{
        	$(this).next().addClass('active');
        	$(this).children('img').css('transform','rotate(90deg)');
        }
	})
  
    $(document).on('click','#about_recruit  .first li',function(){
        $('#about_recruit  .first li').removeClass('active');
        $(this).addClass('active');
        $('#about_recruit  .second  .boxs').removeClass('active');
        $('#about_recruit  .second  .boxs').eq($(this).index()).addClass('active');
	})
    
    $(document).on('click','#solution  .first li',function(){
        $('#solution  .first li').removeClass('active');
        $(this).addClass('active');
        $('#solution  .second  .boxs').removeClass('active');
        $('#solution  .second  .boxs').eq($(this).index()).addClass('active');
	})
    
    
    $(document).on('click','#project .second li',function(){
        $('#project .second li').removeClass('active');
        $(this).addClass('active');
        $('#project  .third  .contents').removeClass('active');
        $('#project  .third  .contents').eq($(this).index()).addClass('active');
	})
})();

(function(){
	$('.datum-left .reveal img').eq(0).show();
	var datumLi = $('.datum-left .carousel ul li').width() + 12;
	var i = 0;
	var mr = 4;
	var dl = setInterval(mov, 3000);
	var dcar = $('.datum-left .carousel ul li').length;// 图片总数
	$('.datum-left .carousel ul').width(dcar * datumLi)
	var beyond = dcar - mr;
	function dtcar() {
		$('.datum-left .carousel ul li').eq(i).addClass('active').siblings()
				.removeClass('active')
		$('.datum-left .reveal img').eq(i).show().siblings().hide();
	}
	function datum() {
		if (i > mr - 1) {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : -beyond * datumLi
			}, 1000)
		} else {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : 0
			}, 0)
		}
	}

	function mov() {
		if (i < dcar - 1) {
			i++
		} else {
			i = 0
		}
		dtcar();
		datum()
	}
	
	// 鼠标移入时候
	$('.datum-left .carousel .but').hover(function() {
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
	
	$('.prev').click(function() {
		i = (i > 0) ? (--i) : (dcar - 1);// 如果 i > 0 则让i--，否则 i = dcar - 1
		dtcar()
		datum()
	})
	
	$('.next').click(function() {
		i = (i < dcar - 1) ? (++i) : 0;// 如果 i < dcar - 1 则让 i++，否则 i = 0
		dtcar()
		datum()
	})
	
	$('.datum-left .carousel ul li').hover(function() {
		i = $(this).index();
		dtcar();
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
})();
(function(){ 
	var num=0;
	setInterval(function messages(){
		var mseg=$('#main .first .mesg ul');
		var tops=parseInt(mseg.css('top'));
		if (tops<(-mseg.height())) {
	       num=10;
		}
		num+=-10;
		mseg.css('top',num);
	},1000);
})();
(function(){ 
	var targets=$('#main .ninth .boxs');
		var targets3=$('#main .ninth .boxs .top');
		var boxs_bg=$('#boxs_bg').attr('src');
		console.log(targets);
		targets.hover(
		  function () {
//		  	console.log($(this).index());
            if ($(this).index()==0||$(this).index()==2) {
//          	$(this).parent('.content').css('margin-right','-0.3rem');
            	$(this).css('margin-right','-0.3rem');
//          	$(this).css('padding-left','0.26rem');
//          	$(this).css('margin-right','0.2rem');
            }else if ($(this).index()==1||$(this).index()==3) {
//          	$(this).parent('.content').css('margin-left','-0.3rem');
            	$(this).css('margin-left','-0.3rem');
            } else{
            	$(this).parent('.content').css('margin','0');
            }
            if ($(this).index()==0) {
            	$(this).css('padding-top','0.3rem');
            	$(this).css('margin-top','-0.1rem');
//          	$('#main .ninth .boxs').eq(0).css('margin-bottom','0.8rem');
//          	$('#main .ninth .boxs').eq(1).css('margin-bottom','0.8rem');
            }
            if ($(this).index()==1) {
            	$(this).css('padding-top','0.3rem');
            	$(this).css('margin-top','-0.1rem');
//          	$('#main .ninth .boxs').eq(0).css('margin-bottom','0.8rem');
//          	$('#main .ninth .boxs').eq(1).css('margin-bottom','0.8rem');
            }
            
            $(this).children('.more').css('display','block');
		  	$(this).css('transform','scale(1.1)');
		  	$(this).children('.more').css('transform','scale(0.9)');
		  	$(this).children('ol').css('transform','scale(0.9)');
		  	$(this).children('ol').css('padding','0.1rem');
		  	$(this).css('background-color','#fff');
		  	$(this).css('z-index','999');
		  	var boxs_bg=$(this).children('#boxs_bg').attr('src');
		    $(this).children('.top').css('background-image','url('+boxs_bg+')');
		    $(this).children('.top').children('.p1').css('color','#FFF');
		    $(this).children('.top').css('height','1.74rem');
		    $(this).children('.top').children('.p1').css('line-height','1.74rem');
		  },
		  function () {
		  	$(this).css('padding-top','0rem');
		  	$(this).css('margin-bottom','0.4rem');
		  	$(this).parent('.content').css('padding-left','0px');
		  	$(this).children('.more').css('display','none');
		  	$(this).css('margin-top','0.3rem');
		  	$(this).css('margin-left','0');
            $(this).css('margin-bottom','0.3rem');
		  	$(this).parent('.content').css('margin','0');
		  	$(this).css('transform','scale(1)');
		  	$(this).children('ol').css('padding','0.2rem');
		  	$(this).children('ol').css('transform','scale(1)');
		  	$(this).children('.more').css('transform','scale(1)');
		  	$(this).css('z-index','111');
		    $(this).children('.top').css('background-image','');
		    $(this).children('.top').css('height','1.4rem');
		    $(this).children('.top').children('.p1').css('color','#313131');
		    $(this).children('.top').children('.p1').css('line-height','1.4rem');
		  }
		);
})();

(function(){ 
	_init_area();
	var Gid  = document.getElementById;
    var showArea = function(){
		Gid('show').innerHTML = "<h3>省" + Gid('s_province').value + " - 市" + 	
		Gid('s_city').value + " - 县/区" + 
		Gid('s_county').value + "</h3>"
	}
  Gid('s_county').setAttribute('onchange','showArea()')
})();