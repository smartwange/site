!(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
		changeIndex();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
	
	function changeIndex(){
		var wid = document.documentElement.clientWidth;
		if (wid>750) {
			window.location.reload("http://whtxht.com/wap/index.html");
		}
	}
})();
!(function(){
	$(document).on('click','#menu',function(){
		$('#banner nav').css("display","block");
	})
	$(document).on('click','#close',function(){
        $('#banner nav').css("display","none");
	})
})();