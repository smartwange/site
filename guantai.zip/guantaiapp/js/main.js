(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();
!(function(){
	var mySwiper = new Swiper("#banner .swiper-container",{
	    autoplay: {
		    delay: 6000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
	});
})();
!(function(){
	$(document).on('click','#top .nav',function(){
		if ($(this).parent().siblings('.navlist').css('display')=='none') {
			$(this).addClass('active');
			$(this).parent().siblings('.navlist').css('display','block');
		}else{
			$(this).removeClass('active');
			$(this).parent().siblings('.navlist').css('display','none');
		}
	})
})();
!(function(){
	$("#main .fourth .subnavs li").on('click',function() {
		$("#main .fourth .subnavs li").removeClass('active');
		$(this).addClass('active');
		$("#main .fourth .contents .boxs").removeClass('active');
		$("#main .fourth .contents .boxs").eq($(this).index()).addClass('active');
	})
})();
!(function(){
    var mySwiper3 = new Swiper("#main .seventh .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    slidesPerView : 3,
	    navigation: {
	      nextEl: '.swiper-button-prev',
	      prevEl: '.swiper-button-next',
	    },
		    
	});
})();

!(function(){
    $(document).on('click','#toTop',function(){
    	$('body,html').scrollTop(0);
    })
})();
!(function(){
	$("#product .down .change li").on('click',function() {
		$("#product .down .change li").removeClass('active');
		$(this).addClass('active');
	})
})();
!(function(){
    var mySwiper3 = new Swiper("#about .content .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
        spaceBetween:30,
	    loop:true,
	    slidesPerView : 2,
	    navigation: {
	      nextEl: '.swiper-button-prev',
	      prevEl: '.swiper-button-next',
	    },
		    
	});
})();