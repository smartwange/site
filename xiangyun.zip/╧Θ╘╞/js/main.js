(function(){
    var swiper = new Swiper('.swiper-container', {
		  autoplay:3000,
		   pagination: '.swiper-pagination',
		   paginationClickable: true,
		    loop: true,
		});
		var swiper3 = new Swiper('.swiper-container3', {
	      autoplay:3800,
		  slidesPerView:3,
		  prevButton:'.swiper-button-prev',
		  nextButton:'.swiper-button-next',
		});
		var swiper5 = new Swiper('.swiper-container5', {
			autoplay:4000,
		  slidesPerView:4,
		  prevButton:'.swiper-button-prev',
		  nextButton:'.swiper-button-next',
		});
})();

//(function(){ 
//
// function verfiy(){
// 	    $('#banner .forms .subs').on('click',function(){
//	 	  console.log(#banner .forms input[name$='name']);
//	 	  return false;
//	    })
// }
//})();
(function(){ 
	var num=0;
	setInterval(function messages(){
		var mseg=$('#banner .mesg ul');
		var tops=parseInt(mseg.css('top'));
		if (tops<(-mseg.height())) {
	       num=10;
		}
		num+=-10;
		mseg.css('top',num);
	},1000);
})();


(function(){ 
	$(document).on('click','#about_recruit .contents .left li',function(){
		$('#about_recruit .contents .left li').removeClass('active');
		$(this).addClass('active');
		$('#about_recruit .contents .right .boxs').removeClass('active');
		$('#about_recruit .contents .right .boxs').eq($(this).index()).addClass('active');
	})
})();

(function(){
	$(document).on('click','#links .sub_nav .left li',function(){
		$('#links .sub_nav .left li').removeClass('active');
		$(this).addClass('active');
		$('#links .contents .boxs').removeClass('active');
		$('#links .contents .boxs').eq($(this).index()).addClass('active');
	})
})();

(function(){
	$(document).on('click','#solution .sub_nav .left li',function(){
		$('#solution .sub_nav .left li').removeClass('active');
		$(this).addClass('active');
		$('#solution .contents').removeClass('active');
		$('#solution .contents').eq($(this).index()).addClass('active');
	})
})();

(function(){
	$(document).on('click','#project .navs  li',function(){
		$('#project .navs  li').removeClass('active');
		$(this).addClass('active');
		$('#project .contents').removeClass('active');
		$('#project .contents').eq($(this).index()).addClass('active');
	})
})();

(function(){
	$('.datum-left .reveal img').eq(0).show();
	var datumLi = $('.datum-left .carousel ul li').width() + 12;
	var i = 0;
	var mr = 4;
	var dl = setInterval(mov, 3000);
	var dcar = $('.datum-left .carousel ul li').length;// 图片总数
	$('.datum-left .carousel ul').width(dcar * datumLi)
	var beyond = dcar - mr;
	function dtcar() {
		$('.datum-left .carousel ul li').eq(i).addClass('active').siblings()
				.removeClass('active')
		$('.datum-left .reveal img').eq(i).show().siblings().hide();
	}
	function datum() {
		if (i > mr - 1) {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : -beyond * datumLi
			}, 1000)
		} else {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : 0
			}, 0)
		}
	}

	function mov() {
		if (i < dcar - 1) {
			i++
		} else {
			i = 0
		}
		dtcar();
		datum()
	}
	
	// 鼠标移入时候
	$('.datum-left .carousel .but').hover(function() {
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
	
	$('.prev').click(function() {
		i = (i > 0) ? (--i) : (dcar - 1);// 如果 i > 0 则让i--，否则 i = dcar - 1
		dtcar()
		datum()
	})
	
	$('.next').click(function() {
		i = (i < dcar - 1) ? (++i) : 0;// 如果 i < dcar - 1 则让 i++，否则 i = 0
		dtcar()
		datum()
	})
	
	$('.datum-left .carousel ul li').hover(function() {
		i = $(this).index();
		dtcar();
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
})();


(function(){ 
	var targets=$('#main .ninth .boxs');
		var targets3=$('#main .ninth .boxs .top');
		var boxs_bg=$('#boxs_bg').attr('src');
		console.log(targets);
		targets.hover(
		  function () {
//		  	console.log($(this).index());
            if ($(this).index()==0) {
            	$(this).parent('.content').css('margin-left','-28px');
            	$(this).css('margin-left','18px');
            }else if ($(this).index()==3) {
            	$(this).parent('.content').css('margin-right','-28px');
            } else{
            	$(this).parent('.content').css('margin','0');
            }
            $(this).children('.more').css('display','block');
            $(this).css('margin-top','-5px');
		  	$(this).css('transform','scale(1.1)');
		  	$(this).children('.more').css('transform','scale(0.9)');
		  	$(this).children('ol').css('transform','scale(0.9)');
		  	$(this).children('ol').css('padding','10px');
		  	$(this).css('background-color','#fff');
		  	$(this).css('z-index','999');
		  	var boxs_bg=$(this).children('#boxs_bg').attr('src');
		    $(this).children('.top').css('background-image','url('+boxs_bg+')');
		    $(this).children('.top').children('.p1').css('color','#FFF');
		    $(this).children('.top').css('height','174px');
		    $(this).children('.top').children('.p1').css('line-height','174px');
		  },
		  function () {
		  	$(this).parent('.content').css('padding-left','0px');
		  	$(this).children('.more').css('display','none');
		  	$(this).css('margin-top','30px');
		  	$(this).css('margin-left','0');
            $(this).css('margin-bottom','30px');
		  	$(this).parent('.content').css('margin','0');
		  	$(this).css('transform','scale(1)');
		  	$(this).children('ol').css('padding','20px');
		  	$(this).children('ol').css('transform','scale(1)');
		  	$(this).children('.more').css('transform','scale(1)');
		  	$(this).css('z-index','111');
		    $(this).children('.top').css('background-image','');
		    $(this).children('.top').css('height','140px');
		    $(this).children('.top').children('.p1').css('color','#313131');
		    $(this).children('.top').children('.p1').css('line-height','140px');
		  }
		);
})();
(function(){ 
	_init_area();
	var Gid  = document.getElementById ;
    var showArea = function(){
		Gid('show').innerHTML = "<h3>省" + Gid('s_province').value + " - 市" + 	
		Gid('s_city').value + " - 县/区" + 
		Gid('s_county').value + "</h3>"
	}
  Gid('s_county').setAttribute('onchange','showArea()');
})();
