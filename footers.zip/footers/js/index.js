(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();
(function(){
	$(document).on('click','#menu',function(){
		if ($(this).parent('nav').siblings('ul').css('display')=='none') {
			$(this).css('background-image','url("img/menu1.png")');
		    $(this).css('height','0.41rem');
		     $(this).parent('nav').siblings('ul').css('display','block');
		     $(this).parent('nav').siblings('.left').children('strong').css('color','#c57229');
		     $(this).parent('nav').siblings('.left').children('span').css('color','#c57229');
		    $(".banner").css('background-color','#010100');
		    $(".banner").children('img').hide();
		} else{
			$(this).css('background-image','url("img/menu.png")');
		    $(this).css('height','0.24rem');
		    $(this).parent('nav').siblings('ul').css('display','none');
		     $(this).parent('nav').siblings('.left').children('strong').css('color','#000');
		     $(this).parent('nav').siblings('.left').children('span').css('color','#fff');
		    $(".banner").css('background-color','');
		    $(".banner").children('img').show();
		}
	})
})();



(function(){
	$(function(){
		$('.intro .top').find('li').click(function(){
			$('.intro .top').find('li').removeClass("active");
			$(this).addClass("active");
			$('.intro .down').find('.contents').removeClass("active");
			$('.intro .down').find('.contents').eq($(this).index()).addClass("active");
		})
	})
})();

$(function(){
    	  	  
  var ovideo=$("#video-btn");
  var oatn=$("#video-area");
  var oshadow=$("#shadow");
  
  ovideo.offset({top:ovideo.scrollTop()+" px"});
  
  $(document).on('click','#video',function(){
	  	ovideo.css("display","block");
	    oshadow.css("display","block");
	    var srcs=$(this).children("#video_src").children("source")[0].src;
	    oatn.html('<video src="'+srcs+'" controls preload  width="100%" height="100%"></video>');
  })
  $("#video-shut").click(function(){
    ovideo.css("display","none");
    oshadow.css("display","none");
	  })
  })