!(function(){
	var mySwiper = new Swiper("#banner .swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
	});
	
})();
!(function(){
	function swiper1(){
		var mySwiper3 = new Swiper("#main .fifth .boxs .swiper1",{
		    autoplay: {
			    delay: 4000,
			    stopOnLastSlide: false,
			    disableOnInteraction: false,
		    },
		    loop:true,
		    slidesPerView : 3,
		    navigation: {
		      nextEl: '.next1',
		      prevEl: '.prev1',
		    },
		    
		});
	}
	function swiper4(){
		var mySwiper4 = new Swiper("#main .fifth .boxs .swiper4",{
		    autoplay: {
			    delay: 4000,
			    stopOnLastSlide: false,
			    disableOnInteraction: false,
		    },
		    loop:true,
		    slidesPerView : 3,
		    navigation: {
		      nextEl: '.next4',
		      prevEl: '.prev4',
		    },
		    
		});
	}
	function swiper5(){
		var mySwiper5 = new Swiper("#main .fifth .boxs .swiper5",{
		    autoplay: {
			    delay: 4000,
			    stopOnLastSlide: false,
			    disableOnInteraction: false,
		    },
		    loop:true,
		    slidesPerView : 3,
		    navigation: {
		      nextEl: '.next5',
		      prevEl: '.prev5',
		    },
		    
		});
	}
	
	swiper1();
	$(document).on('click','#main .fifth .navs li',function(){
		$('#main .fifth .navs li').removeClass('active');
		$(this).addClass('active');
		$('#main .fifth .contents .boxs').removeClass('active');
		$('#main .fifth .contents .boxs').eq($(this).index()).addClass('active');
		console.log($(this).index());
		switch ($(this).index()){
			case 0:
			    swiper1();
				break;
		    case 1:
			    swiper4();
				break;
			case 2:
			    swiper5();
				break;
			default:
				break;
		}
	})
})();


!(function(){
	//当滚动距离大于152px(导航栏顶部的距离)，让导航栏top变为0  banner margin-top: 74px;；
	//小于152px时position应该为relative，
	$(window).scroll(function(){
        var top=$('html,body').scrollTop();
        if (top>152) {
        	$('nav').css('position','fixed');
        	$('nav').css('top','0');
        } else{
        	$('nav').css('position','relative');
        	$('nav').css('top','');
        }
	})
})();


!(function(){
	$('.datum-left .reveal img').eq(0).show();
	var datumLi = $('.datum-left .carousel ul li').width() + 12;
	var i = 0;
	var mr = 4;
	var dl = setInterval(mov, 3000);
	var dcar = $('.datum-left .carousel ul li').length;// 图片总数
	$('.datum-left .carousel ul').width(dcar * datumLi)
	var beyond = dcar - mr;
	function dtcar() {
		$('.datum-left .carousel ul li').eq(i).addClass('active').siblings()
				.removeClass('active')
		$('.datum-left .reveal img').eq(i).show().siblings().hide();
	}
	function datum() {
		if (i > mr - 1) {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : -beyond * datumLi
			}, 1000)
		} else {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : 0
			}, 0)
		}
	}

	function mov() {
		if (i < dcar - 1) {
			i++
		} else {
			i = 0
		}
		dtcar();
		datum()
	}
	
	// 鼠标移入时候
	$('.datum-left .carousel .but').hover(function() {
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
	
	$('.prev').click(function() {
		i = (i > 0) ? (--i) : (dcar - 1);// 如果 i > 0 则让i--，否则 i = dcar - 1
		dtcar()
		datum()
	})
	
	$('.next').click(function() {
		i = (i < dcar - 1) ? (++i) : 0;// 如果 i < dcar - 1 则让 i++，否则 i = 0
		dtcar()
		datum()
	})
	
	$('.datum-left .carousel ul li').hover(function() {
		i = $(this).index();
		dtcar();
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
})();