(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();

(function(){
	var mySwiper = new Swiper(".swiper-container",{
	    autoplay: {
	    delay: 4000,
	    stopOnLastSlide: false,
	    disableOnInteraction: true,
	    },
	    loop:true,
	    autoplayDisableOnInteraction:false,
	    pagination: {
		    el: '.swiper-pagination',
		},
	    paginationClickable:true,
	})
	
//	订货补贴规则说明
   $(document).on('click','#resgister #subs',function(){
        $('#confirms').css('display','block');
   })
   

   
//点击加入购物车弹框
	$(document).on('click','#mall #addTocart',function(event){
		    event.preventDefault();
	   	    $('#goodsDetail').css('display','block');
	})
	$(document).on('click','#recommend #addTocart',function(event){
		    event.preventDefault();
	   	    $('#goodsDetail').css('display','block');
	})
	//详情页
	$(document).on('click','#goodsSpecifics #changeMore',function(){
	   	    $('#goodsDetail').css('display','block');
	})
	//购物车
	$(document).on('click','#shoppingCart #changeMore',function(){
	   	    $('#goodsDetail').css('display','block');
	})
   $(document).on('click','#goodsDetail li>span',function(){
   	    $(this).parent('li').siblings('li').removeClass('active');
        $(this).parent('li').addClass('active');
   })
   
   $(document).on('click','#goodsDetail li>button',function(){
   	    $(this).parent('li').siblings('li').removeClass('active');
        $(this).parent('li').addClass('active');
   })
   
   $(document).on('click','#goodsDetail #close',function(){
   	   $('#goodsDetail').css('display','none');
   })
})();


//注册提交返回页面
(function(){
   $(document).on('click','#OrderSubsidy .mores',function(){
   	
   	   $('#OrderSubsidy').css('display','none');
   })
})();


(function(){
    $(function(){
//	   
	    $(document).on('click','#add',function(){
	    	 var t = $(this).siblings("#text_box");
	         t.val(parseInt(t.val())+1);
	        return false;
	    })
	    
	    $(document).on('click','#min',function(){
	    	var t = $(this).siblings("#text_box");
	    	if (t.val()<=0) {
	    		t.val(0);
	    	} else{
	            t.val(parseInt(t.val())-1);
	    	}
	        return false;
	    })
	   
	   $(document).on('click','#footer3 #alls',function(){
	   	   var isCheck=$("#shoppingCart .boxs").find("input[type='checkbox']");
            if ($(this).is(":checked")) {
            	$(this).parent('.change').siblings('p').text('取消');
            	isCheck.prop("checked",true);
            } else{
            	$(this).parent('.change').siblings('p').text('全选');
            	isCheck.prop("checked",false);
            }
	   })
	})
})();

//全部订单
(function(){
   $(document).on('click','#myOrder .navs li',function(){
   	  $('#myOrder .navs li').removeClass('active');
   	  $(this).addClass('active');
   	  $('#myOrder .units').removeClass('active');
   	  $('#myOrder .units').eq($(this).index()).addClass('active');
   })
   
   $(document).on('click','#messageCenter .navs li',function(){
   	  $('#messageCenter .navs li').removeClass('active');
   	  $(this).addClass('active');
   	  $('#messageCenter .units').removeClass('active');
   	  $('#messageCenter .units').eq($(this).index()).addClass('active');
   })
   
   $(document).on('click','#coupon .navs li',function(){
   	  $('#coupon .navs li').removeClass('active');
   	  $(this).addClass('active');
   	  $('#coupon .units').removeClass('active');
   	  $('#coupon .units').eq($(this).index()).addClass('active');
   })
   
   $(document).on('click','#personCount .subnavs li',function(){
   	  $('#personCount .subnavs li').removeClass('active');
   	  $(this).addClass('active');
   	  $('#personCount .contents').removeClass('active');
   	  $('#personCount .contents').eq($(this).index()).addClass('active');
   })
   //备货中
   $(document).on('click','#myOrder #takeGoods',function(event){
	    event.preventDefault();
   	    $('#stockUp').css('display','block');
	})
   
   $(document).on('click','#stockUp  #close',function(event){
	    event.preventDefault();
   	    $(this).parents('#stockUp').css('display','none');
	})
   
   //自提信息选择
   $(document).on('click','#placeOrder #takeByself',function(){
   	    $('#changeAddress').css('display','block');
	})
   
   $(document).on('click','#changeAddress  #close',function(){
   	    $(this).parents('#changeAddress').css('display','none');
	})
   
   //城市选择联动
   $(document).on('change','#changeAddress  #city',function(e){
// 	    console.log($('#changeAddress  #city option:selected').text());
        var opts=document.getElementById('addresss').children;
        console.log(opts);
        console.log(opts[e.currentTarget.selectedIndex]);
        opts[e.currentTarget.selectedIndex].selected=true;
        
	})
   
   
   //配送信息
   $(document).on('click','#myOrder #getGoods',function(event){
	    event.preventDefault();
   	    $('#distribution').css('display','block');
	})
   
   $(document).on('click','#distribution  #close',function(event){
	    event.preventDefault();
   	    $(this).parents('#distribution').css('display','none');
	})
   
// 物流信息
   $(document).on('click','#myOrder #trackGoods',function(event){
	    event.preventDefault();
   	    $('#express').css('display','block');
	})
   
   $(document).on('click','#express  #close',function(event){
	    event.preventDefault();
   	    $(this).parents('#express').css('display','none');
	})
})();