!(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 19.2+ 'px';
	}
})();

!(function(){
	var mySwiper = new Swiper(".swiper-container",{
	    autoplay: {
		    delay: 4000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
	})
})();

!(function(){
	wow = new WOW({
      　　     animateClass: 'animated',
    });
    wow.init();
    $('.container').addClass("wow fadeInUp");
    var higs=document.documentElement.clientHeight;
//  if (window.scrollTo()>higs) {
//  	
//  }
//  
//	if (window.pageYOffset>higs) {
//      window.scroll(function(){
//	     	wow = new WOW({
//	      　　     animateClass: 'animated',
//		    });
//		    wow.init();
//		    $('.container').addClass("wow fadeInDown");
//		})
//  }
//   window.scroll(function(){
//   	wow = new WOW({
//    　　     animateClass: 'animated',
//	    });
//	    wow.init();
//	    $('.container').addClass("wow fadeInDown");
//   })

var is_running = true;
document.onmousewheel !== undefined ? "mousewheel" : "DOMMouseScroll";
window.onmousewheel=wheelHander;
function wheelHander(event){
   event = event || window.event;
   console.log(event);
    if(event.wheelDelta){
　　       if(event.wheelDelta>0){
	       if (is_running) {
	       	    is_running = false;
	       	    wow = new WOW({
		    　　       animateClass: 'animated',
			    });
			    wow.init();
			    $('.container').addClass("wow fadeInDown");  
	       }
       }
	}else if (event.detail){
	　　 if(event.detail>0){
		    if (is_running) {
		        is_running = false;
		       	wow = new WOW({
			    　　       animateClass: 'animated',
				});
				wow.init();
				$('.container').addClass("wow fadeInDown");
	        }
		}
	}
}


})();

!(function(){
	$('#service input[type=file]').change(function(){
//		console.log($(this).val());
//		console.log($(this).siblings('.sp1'));
        var strs=$(this).val();
        var tt=strs.lastIndexOf('\\');
        var tt3=strs.lastIndexOf('.');
//      console.log(strs.slice(tt3+1));
        var vals=strs.slice(tt3+1);
        
        if (strs!=""&&(vals=="png"||vals=="jpg"||vals=="jpeg")) {
//      if (strs!=""&&(vals!="png"||vals!="jpg"||vals!="jpeg")) {
        	$(this).siblings('.sp1').text(strs.slice(tt+1));
        	$(this).siblings('.sp1').css('color','#828282');
        }else if(strs!=""&&(vals!="png"||vals!="jpg"||vals!="jpeg")){
        	$(this).siblings('.sp1').text('Allowed file extensions to upload: png,jpg,jpeg');
        	$(this).siblings('.sp1').css('color','#f71919');
        }else{
        	$(this).siblings('.sp1').css('color','#828282');
        	$(this).siblings('.sp1').text('Unselected file');
        }
	})
})();


!(function(){
   $('#prodel #pronums').attr("value",$('#prodel #needs').val());
   console.log($('#prodel #pronums').val());
   $(document).on('change',$('#prodel #needs'),function(){
   	   $('#prodel #pronums').attr("value",$('#prodel #needs').val());
   	   console.log($('#prodel #pronums').val());
   })
var arr1=[];
$('#prodel .price .p3').each(function(){
	var num1=$(this).text().slice($(this).text().indexOf('$')+1);
	arr1.push((Number(num1)).toFixed(1));
})
//console.log(arr1);

var arr3=[];
//var arr5=[];
$('#prodel .price .p1').each(function(){
	var num3=$(this).text().slice(0,$(this).text().indexOf('-')-1);
//	var num5=$(this).text().slice($(this).text().indexOf('-')+1);
	arr3.push((Number(num3)));
//	arr5.push((Number(num5)));
})
arr3[arr3.length-1]=parseInt($('#prodel .price li:last-child .p1')[0].innerText.replace(/[^0-9]/gi,''));

console.log(arr3);
//console.log(arr5);

$(document).on('input',$('#prodel #needs'),function(){
    var ts=parseInt($('#prodel #needs').val());
    var prices=$('#prodel #prices');
    
//  console.log(ts);
    for (var i=0;i<arr3.length;i++) {
//  	for (var j=0;j<arr5.length;j++) {
//  		if (ts>=arr3[i]&&ts<=arr5[j]) {
    		if (ts>=arr3[i]) {
	    		console.log(arr1[i]);
	            prices.text(arr1[i]);
	    	}
//  	}
    }
    
})
})();


!(function(){
	$('.datum-left .reveal img').eq(0).show();
	var datumLi = $('.datum-left .carousel ul li').width() + 12;
	var i = 0;
	var mr = 4;
	var dl = setInterval(mov, 3000);
	var dcar = $('.datum-left .carousel ul li').length;// 图片总数
	$('.datum-left .carousel ul').width(dcar * datumLi)
	var beyond = dcar - mr;
	function dtcar() {
		$('.datum-left .carousel ul li').eq(i).addClass('active').siblings()
				.removeClass('active')
		$('.datum-left .reveal img').eq(i).show().siblings().hide();
	}
	function datum() {
		if (i > mr - 1) {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : -beyond * datumLi
			}, 1000)
		} else {
			$('.datum-left .carousel ul').animate({
				'marginLeft' : 0
			}, 0)
		}
	}

	function mov() {
		if (i < dcar - 1) {
			i++
		} else {
			i = 0
		}
		dtcar();
		datum()
	}
	
	// 鼠标移入时候
	$('.datum-left .carousel .but').hover(function() {
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
	
	$('.prev').click(function() {
		i = (i > 0) ? (--i) : (dcar - 1);// 如果 i > 0 则让i--，否则 i = dcar - 1
		dtcar()
		datum()
	})
	
	$('.next').click(function() {
		i = (i < dcar - 1) ? (++i) : 0;// 如果 i < dcar - 1 则让 i++，否则 i = 0
		dtcar()
		datum()
	})
	
	$('.datum-left .carousel ul li').hover(function() {
		i = $(this).index();
		dtcar();
		clearInterval(dl);
	}, function() {
		dl = setInterval(mov, 3000);
	})
})();

