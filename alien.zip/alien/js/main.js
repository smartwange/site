(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 7.5+ 'px';
	}
})();

(function(){
    $(document).on('click','#answer .toggle .tittles',function(){
   	    if ($(this).siblings('.tog').css('display')=='none') {
   	    	$(this).children('img').css('transform','rotateX(180deg)');
   	    	$(this).siblings('.tog').css('display','block');
   	    } else{
   	    	$(this).children('img').css('transform','rotateX(0deg)');
   	    	$(this).siblings('.tog').css('display','none');
   	    }
	})
    
     $(document).on('click','#answer .tog a',function(){
     	if ($(this).siblings('.p3').css('display')=='none') {
   	    	$(this).siblings('.p3').css('display','block');
   	    } else{
   	    	$(this).siblings('.p3').css('display','none');
   	    }
	})
})();


(function(){
	$('#shop .fifth li').not('.unable').click(function(){
		$('#shop .fifth li').removeClass('active');
		$(this).addClass('active');
	})
})();
(function(){
    $(document).on('click','#shop  #next',function(event){
	    event.preventDefault();
	    var isChange=$('#shop .fifth li.active');
	    if ($('#shop .fifth li').hasClass('active')) {
//	    	console.log(isChange.index());
	    	$('#shopInfo #info').eq(isChange.index()).css('display','block');
	    }
	})
   
   $(document).on('click','#info  #close',function(event){
	    event.preventDefault();
   	    $(this).parents('#info').css('display','none');
	})
})();


(function(){
//	var targs=$('#main .percentDetail .txts');
//	var targets=targs.text(); 
//	targs.siblings('.precss').css('width',parseInt(targets)+'%');
//	$('#main .percentDetail .precss').css('width',parseInt(targets)+'%');
//	var lengths=$('#main .percentDetail .precss').css('width',parseInt(targets)+'%');
//	console.log(parseInt(targets));
//	console.log(parseInt(width));


	var targs=$('#main .percentlines .txts');
	var targets=targs.text(); 
	targs.siblings('.lins').children('span').css('width',parseInt(targets)+'%');
	
	var targs=$('#main .percentlines3 .txts');
	var targets=targs.text(); 
	targs.siblings('.lins').children('span').css('width',parseInt(targets)+'%');
	
	var targs=$('#shop .percentlines .txts');
	var targets=targs.text(); 
	targs.siblings('.lins').children('span').css('width',parseInt(targets)+'%');


    var arr=[];
    var cols=["#07a1b1","#50d1de","80e5f0","#bcedf2","#e0f8fb"];
    $('#main .percentDetail .txts').each(function(key,val){
    	arr[key]=$(this).text();
    })
    console.log(arr);
    
    $('#main .percentDetail .precss').each(function(key,val){
    	$(this).css('width',parseInt(arr[key])+'%');
    	var wids=parseInt(arr[key]);
    	if (wids>35) {
    		$(this).css('background',cols[0]);
    	} else if (wids>30&&wids<35.1) {
    		$(this).css('background',cols[1]);
    	} else if (wids<30.1&&wids>15){
    		$(this).css('background',cols[2]);
    	} else if (wids<15.1&&wids>10){
    		$(this).css('background',cols[3]);
    	}else{
    		$(this).css('background',cols[4]);
    	}
    })
        
})();

(function(){
	$(document).on('click','#navs',function(){
		$('#nav').css('display','block');
		$('header').css('margin-left','4.6rem');
		$('#main').css('margin-left','4.6rem');
		$('#answer').css('margin-left','4.6rem');
	})
	
	$(document).on('click','#nav  a',function(){
		$('#nav').css('display','none');
		$('header').css('margin-left','0');
		$('#main').css('margin-left','0');
		$('#answer').css('margin-left','0');
	})
})();

(function(){
	 $(function(){
	 	var num=0
	 	function getLoc(){
	     	if (num==-105) {
	     		num=205;
	     	}
	     	num-=1;
	     	$('#main .first').find('.scrollLeft').css('left',num);
	     }
        var timer=setInterval(getLoc,50);
        
        $('#main .first').hover(function(){
        	clearInterval(timer);
        },function(){
        	timer=setInterval(getLoc,50);
        })
    });
})();



(function(){
	var btn = document.getElementById('copy');
//  btn.addEventListener('click', function(e){
    btn.addEventListener('click', function(e){
        var inputText = document.getElementById('code');
        inputText.focus();
        inputText.setSelectionRange(0, inputText.value.length);
        document.execCommand('copy', true);
        e.preventDefault();
    });
    
    var btns = document.getElementById('copys');
    btns.addEventListener('click', function(e){
        var inputTexts = document.getElementById('codes');
        inputTexts.focus();
        inputTexts.setSelectionRange(0, inputTexts.value.length);
        document.execCommand('copy', true);
        e.preventDefault();
    });
    
    var btns3 = document.getElementById('copys3');
    btns3.addEventListener('click', function(e){
        var inputTexts3 = document.getElementById('codes3');
        inputTexts3.focus();
        inputTexts3.setSelectionRange(0, inputTexts3.value.length);
        document.execCommand('copy', true);
        e.preventDefault();
    });
})();

function loginSend(){
	$(document).on('click','#infosmore #close',function(){
     	$('#infosmore').css('display','none');
     })
	var emails=$('#login input[type=email]').val();
	var passwords=$('#login input[type=password]').val();
	if (emails=="") {
		$("#infosmore .p3").html('邮箱地址不能为空!');
		$("#infosmore").css('display','block');
		return false;
	} else if (passwords=="") {
		$("#infosmore .p3").html('密码不能为空!');
		$("#infosmore").css('display','block');
		return false;
	}else{
		return true;
	}
}

function forgetSend(){
	$(document).on('click','#infosmore #close',function(){
     	$('#infosmore').css('display','none');
     })
	var emails=$('#forget input[type=email]').val();
	if (emails=="") {
		$("#infosmore .p3").html('邮箱地址不能为空!');
		$("#infosmore").css('display','block');
		return false;
	}else{
		return true;
	}
}

function signupSend(){
	$(document).on('click','#infosmore #close',function(){
     	$('#infosmore').css('display','none');
     })
	var emails=$('#signUp input[type=email]').val();
	var passwords=$('#signUp input[type=password]').val();
	var checks=$('#signUp #check1').is(':checked');
	var checks2=$('#signUp #check2').is(':checked');
	if (emails=="") {
		$("#infosmore .p3").html('邮箱地址不能为空!');
		$("#infosmore").css('display','block');
		return false;
	} else if (passwords=="") {
		$("#infosmore .p3").html('密码不能为空!');
		$("#infosmore").css('display','block');
		return false;
	} else if(!checks){
		$("#infosmore .p3").html('请勾选注册协议!');
		$("#infosmore").css('display','block');
		return false;
	}else if(!checks2){
		$("#infosmore .p3").html('请勾选注册协议!');
		$("#infosmore").css('display','block');
		return false;
	}else{
		return true;
	}
}


function mainSend(){
	$(document).on('click','#infosmore #close',function(){
     	$('#infosmore').css('display','none');
     })
	var names=$('#main .eleventh  input[type=text]').val();
	var emails=$('#main .eleventh  input[type=email]').val();
	var textareas=$('#main .eleventh textarea').val();
	console.log(names);
	if (names=="") {
		$("#infosmore .p3").html('姓名不能为空!');
		$("#infosmore .content").css('position','fixed');
		$("#infosmore").css('display','block');
		return false;
	} else if (emails=="") {
		$("#infosmore .p3").html('邮箱地址不能为空!');
		$("#infosmore .content").css('position','fixed');
		$("#infosmore").css('display','block');
		return false;
	} else if(textareas=="") {
		$("#infosmore .p3").html('内容不能为空!');
		$("#infosmore .content").css('position','fixed');
		$("#infosmore").css('display','block');
		return false;
	}else{
		return true;
	}
}

function mainSend3(){
	$(document).on('click','#infosmore #close',function(){
     	$('#infosmore').css('display','none');
    })
	var emails=$('#main .twelfth input[type=email]').val();
	if (emails=="") {
		$("#infosmore .p3").html('邮箱地址不能为空!');
		$("#infosmore .content").css('position','fixed');
		$("#infosmore").css('display','block');
		return false;
	}else{
		return true;
	}
}


//wow
(function(){
	wow = new WOW({  
        animateClass:'animated'  
   }); 
    wow.init();
    $("#main .second  .circle").addClass('wow  rotateIn');
    $("#main .third  .boxs").addClass('wow  bounceInUp');
    $("#main .fifth  .boxs").addClass('wow  bounceInUp');
    $("#main .sixth ").addClass('wow  bounceInUp');
    $("#main .seventh ").addClass('wow  bounceInUp');
    $("#main .seventh .boxs").addClass('wow  bounceInRight');
    $("#main .eighth").addClass('wow  bounceInUp');
    $("#main .eighth .boxs").addClass('wow  bounceInRight');
    $("#main .ninth").addClass('wow  bounceInUp');
    $("#main .ninth .boxs .pic").addClass('wow  bounceInRight');
    $("#main .ninth .boxs .txt").addClass('wow  bounceInRight');
    $("#main .tenth").addClass('wow  bounceInUp');
    $("#main .eleventh").addClass('wow  bounceInUp');
    $("#main .twelfth").addClass('wow  bounceInUp');
    $("#main .thirteenth").addClass('wow  bounceInUp');
})();