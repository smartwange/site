(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/19.2+ 'px';
	}
})();

(function(){
   var swiper=new Swiper('#banner .swiper-container', {
	  autoplay:4000,
	  loop: true,
	  prevButton:'.swiper-button-prev',
	  nextButton:'.swiper-button-next',
	  autoplayDisableOnInteraction : false,
	});
	
	var swiper3=new Swiper('#main .swiper-container', {
//	  autoplay:4000,
	  loop: true,
	  prevButton:'.swiper-button-prev',
	  nextButton:'.swiper-button-next',
	  pagination: '.swiper-pagination',
	  paginationClickable: true,
	  autoplayDisableOnInteraction : false,
	});
	
	var swiper5=new Swiper('#main .swiper-container3', {
	  autoplay:4000,
	  loop: true,
	  prevButton:'.swiper-button-prev',
	  nextButton:'.swiper-button-next',
	  paginationClickable: true,
	  autoplayDisableOnInteraction : false,
	});
})();
(function(){
	var marginhig=$('#top nav').height();
	var marginTop=$('footer').height();
    var mainhig=window.innerHeight-marginhig;
    
    $('#banner').css('height',mainhig);
    $('#banner').css('margin-top',marginhig);
    $('#sub_banner').css('margin-top',marginhig);
    $('#main section').css('height',mainhig);
	$(document).on('click','#top .supnav_li',function(){
		$('#top .supnav_li').removeClass('active ');
		$(this).addClass('active');
		$('#main section').css('padding-top','0');
		$('#main section').css('margin-top','0');
//		$('#main section').eq($(this).index()).css('padding-top',marginhig);
		$('#main section').eq($(this).index()).animate({paddingTop:marginhig},500);
		if ($(this).index()==5) {
//         $("html,body").finish().animate({"scrollTop":$("footer").offset().top},500); 
           $('#main section').eq($(this).index()).css('padding-top','0');
           $('#main section').eq($(this).index()).animate({marginTop:-marginTop},500); 
		}
	})
	
	$(document).on('click','#toDown',function(){
		$('#top .supnav_li').removeClass('active ');
		$('#top .supnav_li').eq(0).addClass('active ');
		$('#main section').eq(0).animate({paddingTop:marginhig},500);
	})
	
	windowAddMouseWheel();
    function windowAddMouseWheel() {
	    var scrollFunc = function (e) {
	        e = e || window.event;
	        if (e.wheelDelta) {  //判断浏览器IE，谷歌滑轮事件
	            $('#main section').css('padding-top','0');
	            $('#main section').css('margin-top','0');
	        } else if (e.detail) {  //Firefox滑轮事件
	            $('#main section').css('padding-top','0');
	             $('#main section').css('margin-top','0');
	        }
	    };
	    //给页面绑定滑轮滚动事件
	    if (document.addEventListener) {
	        document.addEventListener('DOMMouseScroll', scrollFunc, false);
	    }
	    //滚动滑轮触发scrollFunc方法
	    window.onmousewheel = document.onmousewheel = scrollFunc;
    }

})();
