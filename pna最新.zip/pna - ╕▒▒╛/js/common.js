!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#consult .sixth .navs li');
    var aMainfivecontents=document.querySelectorAll('#consult .sixth .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#about .fifth .navs li');
    var aMainfivecontents=document.querySelectorAll('#about .fifth .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var aMainfivenavs=document.querySelectorAll('#article .second .navs li');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            if (_this.classList.contains('active')) {
              _this.classList.remove('active');
            }else{
                _this.classList.add('active');
            }
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('.ninth .navs li');
    var aMainfivecontents=document.querySelectorAll('.ninth .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#marriage .third .navs li');
    var aMainfivecontents=document.querySelectorAll('#marriage .third .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#retrieve .sixth .navs li');
    var aMainfivecontents=document.querySelectorAll('#retrieve .sixth .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#retrieve .eight .navs li');
    var aMainfivecontents=document.querySelectorAll('#retrieve .eight .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex;
    var pre=document.querySelector("#pre");
    var next=document.querySelector("#next");
    var personAll=document.querySelector("#main .fourth .navs ul");
    personAll.innerHTML+=personAll.innerHTML;
    var contentAll=document.querySelector("#main .fourth .content");
    contentAll.innerHTML+=contentAll.innerHTML;
    var aperson=document.querySelectorAll("#main .fourth .navs li");
    var aBox=document.querySelectorAll("#main .fourth .content .box");
    var oWidth=aperson[0].offsetWidth;
    personAll.style.width=oWidth*(aperson.length)+'px';
    pre.addEventListener('click', function(){
        if(personAll.offsetLeft<=-(personAll.offsetWidth)/2){
            console.log('left');
            personAll.style.marginLeft=0+'px';
        }else{
            personAll.style.marginLeft=personAll.offsetLeft-oWidth+'px';
        }
    });
    next.addEventListener('click', function(){
        if(personAll.offsetLeft>-oWidth){
            personAll.style.marginLeft=-(personAll.offsetWidth/2)+oWidth+'px';
        }else{
            personAll.style.marginLeft=personAll.offsetLeft+oWidth+'px';
        }
    });
    for (var i = 0; i < aperson.length; i++) {
        aperson[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex=getIndex();
            var abSiblings=aBox[nIndex].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aBox[nIndex].classList.add('active');
        });
    }
})();
!(function(){
    var nIndexs;
    var aMainfivenavs=document.querySelectorAll('#main .fifth .navs li');
    var aMainfivecontents=document.querySelectorAll('#main .fifth .right .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndexs = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndexs=getIndexs();
            var abSiblings=aMainfivecontents[nIndexs].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndexs].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#main .seventh .navs li');
    var aMainfivecontents=document.querySelectorAll('#main .seventh .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
!(function(){
    var nIndex3;
    var aMainfivenavs=document.querySelectorAll('#main .eight .navs li');
    var aMainfivecontents=document.querySelectorAll('#main .eight .content .box');
    for (var i = 0; i < aMainfivenavs.length; i++) {
        aMainfivenavs[i].addEventListener('click', function(){
            var _this=this;
            var apSiblings=_this.parentNode.children;
            for (var i = 0; i < apSiblings.length; i++) {
               apSiblings[i].classList.remove('active');
            }
           _this.classList.add('active');
            var getIndex3 = function () {
                return Array.prototype.slice.call(_this.parentNode.children).indexOf(_this);
            } 
            nIndex3=getIndex3();
            var abSiblings=aMainfivecontents[nIndex3].parentNode.children;
            for (var i = 0; i < abSiblings.length; i++) {
               abSiblings[i].classList.remove('active');
            }
            aMainfivecontents[nIndex3].classList.add('active');
        })
    }
})();
