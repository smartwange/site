(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 19.2+ 'px';
	}
})();

(function(){
    var mySwiper = new Swiper ('.swiper-container', {
	  spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 8000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }         
	});
})();

(function(){
	wow = new WOW({  
        animateClass:'animated'  
   }); 
    wow.init();
    $("#main .first  .left").addClass('wow  slideInLeft');
    $("#main .first  .right").addClass('wow  slideInRight');
    $("#main .second").addClass('wow  bounceInUp');
    $("#main .third").addClass('wow  bounceInUp');
     
    
    $("#abouts .first  .left").addClass('wow  slideInLeft');
    $("#abouts .first  .right").addClass('wow  slideInRight');
    $("#abouts .second").addClass('wow  bounceInUp');
    $("#abouts .third").addClass('wow  bounceInUp');
    
    $("#links .first").addClass('wow  bounceInUp');
    $("#links .second").addClass('wow  bounceInUp');
    $("#info .second  .left").addClass('wow  slideInLeft');
    $("#info .second  .right").addClass('wow  slideInRight');
    $("#download .second  .left").addClass('wow  slideInLeft');
    $("#download .second  .right").addClass('wow  slideInRight');
    $("#works .second  .left").addClass('wow  slideInLeft');
    $("#works .second  .right").addClass('wow  slideInRight');
    $("#infomore .second  .left").addClass('wow  slideInLeft');
    $("#infomore .second  .right").addClass('wow  slideInRight');
    $("#service .second  .left").addClass('wow  slideInLeft');
    $("#service .second  .right").addClass('wow  slideInRight');
    
    
    $(".footers").addClass('wow  slideInUp');
    $(".navs").addClass('wow  slideInLeft');
    
})();	



(function(){
    window.onscroll=function(){
    	var winTop_1=document.documentElement.scrollTop;
	    var winTop_2=document.body.scrollTop;
	    var winTop;
	    (winTop_1>winTop_2)?winTop=winTop_1:winTop=winTop_2;
	    if(winTop>0){
	        $("#toTop").css({'display':'block'});
	    }
	    if(winTop == 0){
	        $("#toTop").css({'display':'none'});
	    }
   }
   $(document).on('click','#toTop',function(){
   	    $('html').animate({ scrollTop: 0 }, 1000);
   })
   
   var t_right=$(".function_list .list").children('.alt_c').width();
   $(".function_list .list").hover(function(){
   	        console.log(t_right);
   	        $(this).children('.alt_c').animate({'right':'50','opacity':'1'},500);
	    },
	    function(){
	   	    $(this).children('.alt_c').css({'right':-t_right,'opacity':'0'},500);
	    }
  );
  
  $(document).on('click','#state_btn',function(){
   	    var rights=parseInt($('.sidebar2_list').css('right'));
   	    if (rights==0) {
   	    	$('.sidebar2_list').css('right','-50px');
   	    	$(this).addClass('cur');
   	    } else{
   	    	$('.sidebar2_list').css('right','0');
   	    	$(this).removeClass('cur');
   	    }
   });
  
  
  $(document).on('click','#prev_btn',function(){
   	    var win = $(window);
		var win_h = win.height();
		var scroll_t = win.scrollTop();
		if(scroll_t != 0){
			if(scroll_t <= win_h){
				$("body,html").animate({"scrollTop":0});
			}else{
				$("body,html").animate({"scrollTop":scroll_t-win_h});
			}
		}
   })
  
  
  $(document).on('click','#next_btn',function(){
   	   var win = $(window);
		var win_h = win.height();
		var scroll_t = win.scrollTop();
		$("body,html").animate({"scrollTop":scroll_t+win_h});
   })
   
})();	