!(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 19.2+ 'px';
	}
})();
$(document).ready(function(){
	ScrollReveal({ reset: true }).reveal('.content',{ duration: 2000 }, 100);
	ScrollReveal({ reset: true }).reveal('.content .box', { duration: 1000, scale: 1.3 });
});
!(function(){
	var mySwiper = new Swiper("#banner .swiper-container",{
	    autoplay: {
		    delay: 400000,
		    stopOnLastSlide: false,
		    disableOnInteraction: false,
	    },
	    loop:true,
	    pagination: {
		    el: '.swiper-pagination',
		     clickable :true,
		},
		navigation: {
	      nextEl: '.swiper-button-next',
	      prevEl: '.swiper-button-prev',
	    },
	});
	
})();
!(function(){
	$('nav').find('ul>li:last-child').mouseenter(function(){
		$("#changeLanguage").css('display','block');
	})
	$('nav').find('ul>li:last-child').mouseleave(function(){
		$("#changeLanguage").css('display','none');
	})
	
    $(document).ready(function(){
//  	var bannershs=$("#banner").css('height');
    	var bannershs=$("#banner").offset().top-90;
    	var firstshs=$("#main .first").offset().top-90;
    	var secondshs=$("#main .second").offset().top-90;
    	var thirdshs=$("#main .third").offset().top-90;
    	var fourthshs=$("#main .fourth").offset().top-90;
    	var fifthshs=$("#main .fifth").offset().top-90;
    	var sixthshs=$("#main .sixth").offset().top-90;
    	$(document).scroll(function(){
	    	if (window.scrollY>parseInt(bannershs)) {
	    		$("#banner nav").css('background','rgba(8,19,56,1)');
	    	}else{
	    		$("#banner nav").css('background','rgba(8,19,56,0.1)');
	    	}
	    	if (window.scrollY>parseInt(secondshs)) {
	    		$("#toTop").css('display','block');
	    	} else{
	    		$("#toTop").css('display','none');
	    	}
	    	$("#banner nav li>a").removeClass('active');
	    	if (parseInt(firstshs)<=window.scrollY&&window.scrollY<parseInt(secondshs)) {
	    		$("#banner nav li").eq(0).children('a').addClass('active');
	    	}
	    	if (parseInt(secondshs)<=window.scrollY&&window.scrollY<parseInt(thirdshs)) {
	    		
	    		$("#banner nav li").eq(1).children('a').addClass('active');
	    	}
	    	if (parseInt(thirdshs)<=window.scrollY&&window.scrollY<parseInt(fourthshs)) {
	    		
	    		$("#banner nav li").eq(2).children('a').addClass('active');
	    	}
	    	if (parseInt(fourthshs)<=window.scrollY&&window.scrollY<parseInt(fifthshs)) {
	    		
	    		$("#banner nav li").eq(3).children('a').addClass('active');
	    	}
	    	if (parseInt(fifthshs)<=window.scrollY&&window.scrollY<parseInt(sixthshs)) {
	    		
	    		$("#banner nav li").eq(4).children('a').addClass('active');
	    	}
	    	if (parseInt(sixthshs)<=window.scrollY) {
	    		$("#banner nav li").eq(5).children('a').addClass('active');
	    	}
	    })
    })
})();
!(function(){
	$("#toTop").click(function(){
		$('html,body').animate({scrollTop:0},500);
	})
})();
!(function(){
	$("#banner nav li").not("#banner nav li:last-child").click(function () {
		var navsection=$("#main section").eq($(this).index()).offset().top;
		$('html,body').animate({scrollTop:navsection-88},500);
		
	})
	
//	$("#banner nav li:last-child .lang").click(function(event){
//		event.preventDefault();
//	})
//  $('#linkmore').siblings('.p3').css('height','72px');
    $("#linkmore").click(function(){
		var pHight=$(this).siblings('.p3').css('height');
		console.log(pHight);
		if (pHight=='72px') {
			$(this).siblings('.p3').css('height','auto');
			$(this).addClass('quitbg');
		} else{
			$(this).siblings('.p3').css('height','72px');
			$(this).removeClass('quitbg');
		}
	})
})();

