!(function(){
   var swiper3=new Swiper('#banner .swiper-container', {
	  autoplay:4000,
	  loop: true,
	  pagination: '.swiper-pagination',
	  paginationClickable: true,
	  autoplayDisableOnInteraction : false,
	});
	
	var swiper5=new Swiper('#main .first .swiper-container', {
	  autoplay:4000,
	  loop: true,
	  pagination: '.swiper-pagination',
	  paginationClickable: true,
	  autoplayDisableOnInteraction : false,
	});
	
    
	var swiper6=new Swiper('#main .second .swiper-container', {
	  autoplay:4000,
	  loop: true,
	  view: 3,
	  pagination: '.swiper-pagination',
	  paginationClickable: true,
	  autoplayDisableOnInteraction : false,
	});
})();
!(function(){
	var heighs=$('nav .subnav').height();
	$('nav .subnav .pic').css('height',heighs);
})();
!(function(){
	$("#main .sixth .change li").on('click',function(){
		$("#main .sixth .change li").removeClass('active');
		$(this).addClass('active');
		$("#main .sixth .contents .boxs").removeClass('active');
		$("#main .sixth .contents .boxs").eq($(this).index()).addClass('active');
	})
})();
!(function(){
	$(document).on('click','#abouts .navs li',function(){
		$('#abouts .navs li').removeClass('active');
		$(this).addClass('active');
		$('#abouts .contents').removeClass('active');
		$('#abouts .contents').eq($(this).index()).addClass('active');
	})
})();
!(function(){
	$(document).on('click','#news .navs li',function(){
		$('#news .navs li').removeClass('active');
		$(this).addClass('active');
		$('#news .contents').removeClass('active');
		$('#news .contents').eq($(this).index()).addClass('active');
	})
})();
!(function(){
	if (document.documentElement.clientWidth<751) {
		$('#products .lefts .navs').eq(0).children('.p1').addClass('active');
		$(document).on('click','#products .lefts .navs .p1',function(){
			$('#products .lefts .navs .p1').removeClass('active');
			$(this).addClass('active');
//			$('#products .lefts .navs .p1').siblings('ul').css('display','none');
			if ($(this).siblings('ul').css('display')=='none') {
				$('#products .lefts .navs .p1').siblings('ul').css('display','none');
				$(this).siblings('ul').css('display','block');
			} else{
				$('#products .lefts .navs .p1').siblings('ul').css('display','none');
				$(this).siblings('ul').css('display','none');
			}
		})
	}
})();

!(function(){
	$(document).on('click','#closevideo',function(){
		document.getElementsByTagName('video')[0].pause();
		$('.forvideo').css("display","none");
	})
	$(document).on('click','#videos',function(){
		$('.forvideo').css("display","block");
	})
	
})();