(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 19.2+ 'px';
	}
})();

(function(){
    $(".focusBox").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:600, trigger:"click"});
    $("#main .right").slide({mainCell:".maincontent",autoPage:true,effect:"leftLoop",autoPlay:true,vis:1});
    $(document).on('click','#hos',function(){
    	if ($(this).siblings('ul').css('display')=='block') {
    		$(this).siblings('ul').css('display','none');
    		$(this).children('span').addClass('cur');
    	} else{
    		$(this).siblings('ul').css('display','block');
    		$(this).children('span').removeClass('cur');
    	}
    })
    
    $(".fBox").slide({ mainCell:".pic",effect:"leftLoop", autoPlay:true, delayTime:600, trigger:"click",vis:4});
    
   $(document).on('click','#toTop_a',function(){
   	    $('html').animate({ scrollTop: 0 }, 1000);
   })
})();