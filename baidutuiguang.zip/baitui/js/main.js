!(function(){
	new WOW().init();
	$('#banner').addClass('wow bounceInDown')
	$('#server .first').addClass('wow bounceInUp')
	$('#server .second').addClass('wow bounceInUp')
	$('#main').addClass('wow bounceInUp')
	$('#statement').addClass('wow bounceInRight')
})();
