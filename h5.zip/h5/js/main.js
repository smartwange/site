(function(){
	fontSize();
	window.onresize=function(){
		fontSize();
	}
	//改变默认字体大小
	function fontSize(){
		var wid = document.documentElement.clientWidth;
		document.documentElement.style.fontSize = wid/ 10.8+ 'px';
	}
})();

(function(){

})();


(function(){
	wow = new WOW({  
        animateClass:'animated'  
   }); 
    wow.init();
    $("#second .pic1").addClass('wow  bounceInUp');
    $("#second .pic3").addClass('wow  bounceInDown');
    $("#third .pic1").addClass('wow  fadeInLeftBig');
    $("#third .pic3").addClass('wow  bounceInUp');
    $("#fourth .pic1").addClass('wow  bounceInDown');
    $("#fourth .pic3").addClass('wow  bounceInRight');
    $("#fifth .pic1").addClass('wow  bounceInUp');
    $("#fifth .pic3").addClass('wow  bounceInDown');
    $("#sixth .pic1").addClass('wow  rotateInDownLeft');
    $("#sixth .pic3").addClass('wow  rotateInDownRight');
    $("#seventh .logos").addClass('wow  slideInDown');
    $("#seventh .pic1").addClass('wow  bounceInUp');
    $("#seventh .pic3").addClass('wow  bounceInDown');
    $("#seventh .pic5").addClass('wow  bounceInDown');
})();